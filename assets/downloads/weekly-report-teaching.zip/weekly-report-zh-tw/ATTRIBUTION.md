# 來源與修改說明

原作：Anthropic，internal-comms。
來源：https://github.com/anthropics/skills/tree/main/skills/internal-comms
參考：https://github.com/anthropics/skills/blob/main/skills/internal-comms/examples/3p-updates.md
取得日期：2026-09-11。原始 main 分支下載內容另保留在教材 materials/weekly-report/upstream/internal-comms。
授權：Apache License 2.0，授權全文附於 LICENSE.txt。

修改日期：2026-09-11。
課堂版本：1.0。
修改內容：縮小為工作週報、改寫繁體中文、統一本週與下週的時間範圍、加入逐筆依據及缺漏／矛盾處理、採用不需外部連線的預設流程，並新增虛構練習。

此版本不是原作者或 OpenAI 的官方版本。來源原文與示例不可當成真實工作資料。
