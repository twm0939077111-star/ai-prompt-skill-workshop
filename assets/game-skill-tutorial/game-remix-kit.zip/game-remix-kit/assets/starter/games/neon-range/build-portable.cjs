const fs=require('fs'),path=require('path');const root=__dirname;
const read=p=>fs.readFileSync(path.join(root,p),'utf8');const data=s=>'data:text/javascript;base64,'+Buffer.from(s).toString('base64');
fs.writeFileSync(path.join(root,'game.js'),read('src/scene.js')+'\n'+read('src/play.js'));
const core=data(read('vendor/three.core.js'));const mod=data(read('vendor/three.module.js').replaceAll("'./three.core.js'",JSON.stringify(core)));const game=read('game.js').replace("'./vendor/three.module.js'",JSON.stringify(mod));
const html=read('index.html').replace('<link rel="stylesheet" href="style.css">','<style>'+read('style.css')+'</style>').replace('<script type="module" src="game.js"></script>','<script type="module">'+game+'</script>');
fs.writeFileSync(path.join(root,'NEON-RANGE-mobile.html'),html);console.log('Portable HTML created: '+Buffer.byteLength(html)+' bytes.');
