import * as THREE from './vendor/three.module.js';
const $=id=>document.getElementById(id),canvas=$('game');
document.body.classList.add('menu');
let renderer;
try{renderer=new THREE.WebGLRenderer({canvas,antialias:true})}catch(e){$('notice').textContent='無法啟用 3D 畫面，請使用支援 WebGL 的 Edge 或 Chrome。';throw e}
renderer.setPixelRatio(Math.min(devicePixelRatio,1.7));renderer.setSize(innerWidth,innerHeight,false);renderer.shadowMap.enabled=true;renderer.shadowMap.type=THREE.PCFSoftShadowMap;renderer.outputColorSpace=THREE.SRGBColorSpace;renderer.toneMapping=THREE.ACESFilmicToneMapping;
const scene=new THREE.Scene();scene.background=new THREE.Color(0x081722);scene.fog=new THREE.FogExp2(0x081722,.022);
const camera=new THREE.PerspectiveCamera(75,innerWidth/innerHeight,.08,130);camera.rotation.order='YXZ';camera.position.set(0,1.65,13);scene.add(camera);
scene.add(new THREE.HemisphereLight(0xbcecff,0x1e2830,2.1));const sun=new THREE.DirectionalLight(0xd0eeff,3);sun.position.set(8,15,10);sun.castShadow=true;sun.shadow.mapSize.set(2048,2048);Object.assign(sun.shadow.camera,{left:-20,right:20,top:20,bottom:-25,near:1,far:60});scene.add(sun);
const material=(color,metalness=.2,roughness=.6)=>new THREE.MeshStandardMaterial({color,metalness,roughness});
const metal=material(0x233d4a,.6),dark=material(0x0b1b25),white=material(0xbacdd0,.5),lime=new THREE.MeshBasicMaterial({color:0xb8ff66}),cyan=new THREE.MeshBasicMaterial({color:0x54e4ef});
function box(w,h,d,x,y,z,mat,parent=scene){const m=new THREE.Mesh(new THREE.BoxGeometry(w,h,d),mat);m.position.set(x,y,z);m.castShadow=true;m.receiveShadow=true;parent.add(m);return m}
box(32,.3,46,0,-.2,-5,material(0x142630));
const grid=new THREE.GridHelper(44,44,0x376071,0x213e4b);grid.position.set(0,-.035,-6);scene.add(grid);
box(32,7,.5,0,3.4,-26,dark);box(.5,7,46,-16,3.4,-3,dark);box(.5,7,46,16,3.4,-3,dark);
for(let x=-14;x<=14;x+=4){box(.1,6,.12,x,3,-25.68,cyan);box(3.7,.06,.14,x+1.9,5.8,-25.6,metal)}
for(let z=-24;z<=16;z+=5){box(.2,6,.24,-15.65,3,z,metal);box(.2,6,.24,15.65,3,z,metal);box(.09,.05,3.2,-15.3,.03,z,cyan);box(.09,.05,3.2,15.3,.03,z,cyan)}
for(let x=-12;x<=12;x+=6){box(.05,.015,36,x,.015,-5,metal);box(1.2,.02,.18,x,.026,7,lime)}
const signCanvas=document.createElement('canvas');signCanvas.width=1024;signCanvas.height=256;const ctx=signCanvas.getContext('2d');ctx.fillStyle='#162d39';ctx.fillRect(0,0,1024,256);ctx.fillStyle='#b8ff66';ctx.font='bold 104px Arial';ctx.textAlign='center';ctx.fillText('NEON RANGE',512,133);ctx.font='24px Arial';ctx.fillStyle='#a3c1ce';ctx.fillText('PRECISION TRAINING  /  SECTOR 01',512,196);const sign=new THREE.Mesh(new THREE.PlaneGeometry(12,3),new THREE.MeshBasicMaterial({map:new THREE.CanvasTexture(signCanvas)}));sign.position.set(0,4.7,-25.65);scene.add(sign);
// Training targets are kept beyond the player's movement area.
const robots=[];const bases=[[-8,-6],[-4,-12],[0,-8],[4,-16],[8,-8]];
bases.forEach(([x,z],i)=>{const g=new THREE.Group();g.position.set(x,0,z);scene.add(g);const bodyMat=material(i%2?0x65b7c5:0xb2c779,.55,.35);const body=box(.85,1.05,.55,0,1.4,0,bodyMat,g);const head=box(.7,.55,.55,0,2.23,0,white,g);box(.54,.17,.035,0,2.25,.3,cyan,g);box(.45,.33,.025,0,1.46,.29,lime,g);for(const s of [-1,1]){box(.22,.68,.25,s*.61,1.42,0,white,g);box(.26,.57,.3,s*.25,.55,0,metal,g);box(.35,.16,.5,s*.25,.21,.07,white,g)}const ring=new THREE.Mesh(new THREE.TorusGeometry(.96,.025,8,40),cyan);ring.rotation.x=Math.PI/2;ring.position.y=.03;g.add(ring);box(2,.12,1.8,x,.02,z,metal);const r={g,x,z,body,head,active:true,respawn:0,i};g.traverse(o=>{if(o.isMesh)o.userData.robot=r});head.userData.head=true;robots.push(r)});
const gun=new THREE.Group();camera.add(gun);gun.position.set(.34,-.3,-.58);box(.21,.22,.6,0,0,0,metal,gun);box(.15,.12,.55,0,.13,-.06,white,gun);box(.12,.11,.38,0,.01,-.43,dark,gun);box(.025,.04,.48,-.11,.06,-.1,cyan,gun);box(.11,.3,.17,0,-.2,.14,dark,gun);const flash=new THREE.Mesh(new THREE.IcosahedronGeometry(.12,0),lime);flash.position.set(0,0,-.67);flash.visible=false;gun.add(flash);gun.traverse(o=>{o.castShadow=false});
