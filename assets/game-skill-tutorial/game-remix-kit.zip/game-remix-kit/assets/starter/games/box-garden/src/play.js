
let current=0,state,history=[],records={};try{records=JSON.parse(localStorage.getItem('box-garden-v1')||'{}')||{}}catch{}
const $=id=>document.getElementById(id),canvas=$('board'),ctx=canvas.getContext('2d');
function recordKey(i=current){return LEVELS[i].seed===undefined?i:'random-'+LEVELS[i].seed;}
const seenMaps=new Set();let challengeNumber=0;
function randomLevel(){
 const a=new Uint32Array(1);
 for(let attempt=0;attempt<100;attempt++){
  crypto.getRandomValues(a);const level=generateLevel(a[0]),fingerprint=level.map.join('\n');
  if(seenMaps.has(fingerprint))continue;
  seenMaps.add(fingerprint);challengeNumber++;
  level.name=`第 ${challengeNumber} 關 · 小花園`;level.sub='挑戰 · 每關不同';
  LEVELS[3]=level;load(3);return;
 }
 $('message').textContent='暫時未產生新的布局，請再按一次換關。';
}
function nav(){document.querySelector('.levels').innerHTML=[3,0,1,2].filter(i=>LEVELS[i]).map(i=>{const l=LEVELS[i];return `<button class="level ${current===i?'active':''}" data-level="${i}" aria-current="${current===i?'step':'false'}"><span class="num">${i===3?'∞':i+1}</span><span><strong>${i===3?'隨機闖關':'練習 '+(i+1)}</strong><small>${i===3?'第 '+challengeNumber+' 關':l.name}</small></span><span class="badge">${records[recordKey(i)]?'✓':'↗'}</span></button>`}).join('');document.querySelectorAll('[data-level]').forEach(b=>b.onclick=()=>load(+b.dataset.level));}
function render(){draw();$('moves').textContent=state.moves;$('goals').textContent=state.boxes.filter(p=>state.goals.includes(p)).length+' / '+state.goals.length;$('undo').disabled=!history.length;$('level-title').textContent=LEVELS[current].name;$('best').textContent=records[recordKey()]?' 最佳：'+records[recordKey()]+' 步':'';$('win').hidden=!won(state);nav();}
function load(i){current=i;state=createState(LEVELS[i]);history=[];$('message').textContent=LEVELS[i].hint;render();}
function move(d){const next=advance(state,d);if(!next){if(!won(state))$('message').textContent='這邊推不動，試試另一個方向。';return;}history.push(state);state=next;$('message').textContent='把每個木箱，送回它的位置。';const trapped=state.boxes.some(p=>!state.goals.includes(p)&&(state.walls.includes(p-1)||state.walls.includes(p+1))&&(state.walls.includes(p-state.width)||state.walls.includes(p+state.width)));if(trapped)$('message').textContent='木箱卡進角落了！按「復原一步」就能救回來。';if(won(state)){records[recordKey()]=Math.min(records[recordKey()]||Infinity,state.moves);try{localStorage.setItem('box-garden-v1',JSON.stringify(records))}catch{}$('win-title').textContent=current===2?'花園整理完成！':'每一箱，都剛剛好。';$('win-copy').textContent=`用了 ${state.moves} 步，完成 ${state.goals.length} 個木箱歸位。`;$('next').textContent='下一關 · 全新地圖 →';$('message').textContent='過關！也可以復原一步，繼續研究更短的路線。';}render();}
function undo(){if(history.length){state=history.pop();$('message').textContent='回到上一步，換個想法再試。';render();}}
$('undo').onclick=undo;$('restart').onclick=()=>load(current);$('replay').onclick=()=>load(current);$('random').onclick=randomLevel;$('next').onclick=randomLevel;$('hint').onclick=()=>{$('message').textContent=LEVELS[current].hint};document.querySelectorAll('[data-dir]').forEach(b=>b.onclick=()=>move(b.dataset.dir));
addEventListener('keydown',e=>{if(e.ctrlKey||e.metaKey||e.altKey)return;const d={ArrowUp:'U',ArrowDown:'D',ArrowLeft:'L',ArrowRight:'R',w:'U',s:'D',a:'L',d:'R'}[e.key]||{w:'U',s:'D',a:'L',d:'R'}[e.key.toLowerCase()];if(d){e.preventDefault();move(d)}else if(e.key.toLowerCase()==='z'){e.preventDefault();undo()}else if(e.key.toLowerCase()==='r'){e.preventDefault();load(current)}});
let touchStart=null;canvas.addEventListener('pointerdown',e=>{touchStart={x:e.clientX,y:e.clientY,id:e.pointerId};canvas.setPointerCapture(e.pointerId)});canvas.addEventListener('pointerup',e=>{if(!touchStart||touchStart.id!==e.pointerId)return;const dx=e.clientX-touchStart.x,dy=e.clientY-touchStart.y;touchStart=null;if(Math.max(Math.abs(dx),Math.abs(dy))<18)return;move(Math.abs(dx)>Math.abs(dy)?dx>0?'R':'L':dy>0?'D':'U')});canvas.addEventListener('pointercancel',()=>touchStart=null);
randomLevel();
if(new URLSearchParams(location.search).has('qa'))window.gameQA={read:()=>JSON.parse(JSON.stringify(state)),load,move,undo,levels:LEVELS,generateLevel,randomLevel};
