
const LEVELS=[
{name:'第一箱的旅行',sub:'01 · 暖身練習',hint:'走到木箱左邊，向右推到金色圓圈。',map:['#######','#     #','#     #','# @$ .#','#     #','#     #','#######']},
{name:'兩箱的默契',sub:'02 · 換個方向',hint:'兩個目的地都在上方。試著從木箱下方往上推。',map:['#######','# . . #','#     #','# $ $ #','#  @  #','#     #','#######']},
{name:'花園小迷宮',sub:'03 · 想好再推',hint:'先把右邊的箱子往上送，再繞到左箱下方。小心別把箱子推進角落。',map:['########','#  . . #','#  #   #','# $  $ #','#   #  #','#  @   #','#      #','########']}
];
const DIR={U:[0,-1],D:[0,1],L:[-1,0],R:[1,0]};
function createState(level){const walls=[],goals=[],boxes=[];let player;level.map.forEach((row,y)=>[...row].forEach((c,x)=>{const p=y*row.length+x;if(c==='#')walls.push(p);if('.+*'.includes(c))goals.push(p);if('$*'.includes(c))boxes.push(p);if('@+'.includes(c))player=p}));return {width:level.map[0].length,height:level.map.length,walls,goals,boxes,player,moves:0};}
function won(s){return s.boxes.every(p=>s.goals.includes(p));}
function advance(s,dir){if(won(s))return null;const [dx,dy]=DIR[dir],x=s.player%s.width,y=Math.floor(s.player/s.width),nx=x+dx,ny=y+dy;if(nx<0||nx>=s.width||ny<0||ny>=s.height)return null;const n=ny*s.width+nx;if(s.walls.includes(n))return null;const boxes=[...s.boxes];if(boxes.includes(n)){const bx=nx+dx,by=ny+dy,b=by*s.width+bx;if(bx<0||bx>=s.width||by<0||by>=s.height||s.walls.includes(b)||boxes.includes(b))return null;boxes[boxes.indexOf(n)]=b;}return {...s,player:n,boxes,moves:s.moves+1};}

// Start solved and pull boxes backwards. Reversing the recorded moves is a legal solution.
function generateLevel(seed){
 seed=seed>>>0;let rng=seed;
 const random=()=>{rng+=0x6D2B79F5;let t=rng;t=Math.imul(t^t>>>15,t|1);t^=t+Math.imul(t^t>>>7,t|61);return ((t^t>>>14)>>>0)/4294967296};
 const pick=a=>a[Math.floor(random()*a.length)], opposite={U:'D',D:'U',L:'R',R:'L'};
 for(let attempt=0;attempt<80;attempt++){
  const width=8,walls=new Set(),floor=[];
  for(let p=0;p<64;p++){const x=p%8,y=Math.floor(p/8);if(!x||x===7||!y||y===7)walls.add(p);else floor.push(p)}
  // Interior obstacles vary the routes; reject disconnected layouts.
  for(let n=0;n<4;n++)walls.add(pick(floor));
  const free=floor.filter(p=>!walls.has(p)),seen=new Set([free[0]]),queue=[free[0]];
  for(const p of queue)for(const d of [-8,8,-1,1])if(!walls.has(p+d)&&!seen.has(p+d)){seen.add(p+d);queue.push(p+d)}
  if(seen.size!==free.length)continue;
  const candidates=free.filter(p=>p%8>1&&p%8<6&&p>15&&p<48);
  if(candidates.length<3)continue;
  const goals=[];while(goals.length<3){const p=pick(candidates);if(!goals.includes(p))goals.push(p)}
  const boxes=[...goals];let player=pick(free.filter(p=>!boxes.includes(p))),pulls=0;const trace=[];
  for(let step=0;step<1200;step++){
   const moves=Object.keys(DIR).filter(d=>{const [x,y]=DIR[d],n=player+x+y*width;return !walls.has(n)&&!boxes.includes(n)});
   if(!moves.length)break;
   const pulling=moves.filter(d=>{const [x,y]=DIR[d];return boxes.includes(player-x-y*width)});
   const d=pick(pulling.length&&random()<0.8?pulling:moves),[dx,dy]=DIR[d],delta=dx+dy*width,b=boxes.indexOf(player-delta);
   if(b>=0){boxes[b]=player;pulls++}player+=delta;trace.push(opposite[d]);
  }
  if(pulls<12||boxes.some(p=>goals.includes(p)))continue;
  const map=Array.from({length:8},(_,y)=>Array.from({length:8},(_,x)=>{const p=y*8+x;return walls.has(p)?'#':p===player?(goals.includes(p)?'+':'@'):boxes.includes(p)?(goals.includes(p)?'*':'$'):goals.includes(p)?'.':' '}).join(''));
  return {name:'隨機小花園',sub:'隨機 · 三箱挑戰',hint:`關卡編號 ${seed} · 三個木箱都有路可到達目的地，先觀察再推。`,seed,map,solution:trace.reverse()};
 }
 // Bounded fallback: three boxes each one push below their goals, always solvable.
 return {name:'隨機小花園',sub:'隨機 · 三箱挑戰',seed,hint:`關卡編號 ${seed} · 從箱子下方往上推。`,map:['########','# . . .#','# $ $ $#','# @    #','#      #','#      #','#      #','########'],solution:['U','D','R','R','U','D','R','R','U']};
}
