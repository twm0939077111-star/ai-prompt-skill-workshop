
const LEVELS=[
{name:'第一箱的旅行',sub:'01 · 暖身練習',hint:'走到木箱左邊，向右推到金色圓圈。',map:['#######','#     #','#     #','# @$ .#','#     #','#     #','#######']},
{name:'兩箱的默契',sub:'02 · 換個方向',hint:'兩個目的地都在上方。試著從木箱下方往上推。',map:['#######','# . . #','#     #','# $ $ #','#  @  #','#     #','#######']},
{name:'花園小迷宮',sub:'03 · 想好再推',hint:'先把右邊的箱子往上送，再繞到左箱下方。小心別把箱子推進角落。',map:['########','#  . . #','#  #   #','# $  $ #','#   #  #','#  @   #','#      #','########']}
];
const DIR={U:[0,-1],D:[0,1],L:[-1,0],R:[1,0]};
function createState(level){const walls=[],goals=[],boxes=[];let player;level.map.forEach((row,y)=>[...row].forEach((c,x)=>{const p=y*row.length+x;if(c==='#')walls.push(p);if(c==='.')goals.push(p);if(c==='$')boxes.push(p);if(c==='@')player=p}));return {width:level.map[0].length,height:level.map.length,walls,goals,boxes,player,moves:0};}
function won(s){return s.boxes.every(p=>s.goals.includes(p));}
function advance(s,dir){if(won(s))return null;const [dx,dy]=DIR[dir],x=s.player%s.width,y=Math.floor(s.player/s.width),nx=x+dx,ny=y+dy;if(nx<0||nx>=s.width||ny<0||ny>=s.height)return null;const n=ny*s.width+nx;if(s.walls.includes(n))return null;const boxes=[...s.boxes];if(boxes.includes(n)){const bx=nx+dx,by=ny+dy,b=by*s.width+bx;if(bx<0||bx>=s.width||by<0||by>=s.height||s.walls.includes(b)||boxes.includes(b))return null;boxes[boxes.indexOf(n)]=b;}return {...s,player:n,boxes,moves:s.moves+1};}
