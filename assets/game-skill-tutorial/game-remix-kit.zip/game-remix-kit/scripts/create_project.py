"""Copy the bundled playable starter to a NEW directory; never overwrite work."""
import argparse
import shutil
from pathlib import Path

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('destination', type=Path)
    args = parser.parse_args()
    source = Path(__file__).resolve().parents[1] / 'assets' / 'starter'
    destination = args.destination.expanduser().resolve()
    if destination.exists():
        parser.error('Destination already exists. Use that project or choose a new folder; nothing was overwritten.')
    if source == destination or source in destination.parents:
        parser.error('Choose a directory outside the skill starter.')
    shutil.copytree(source, destination)
    print(str(destination / 'index.html'))

if __name__ == '__main__':
    main()
