# 原始碼與不易發現的限制

所有路徑相對於建立的個人專案根目錄。

## 推箱子

推箱子來源已分成 `games/box-garden/src/` 下的檔案：

- `art.js`：`draw()` / `rounded()`，完整棋盤、角色、物件視覺，可按主題重畫。
- `style.css`：介面與手機布局。
- `shell.html`：可改的文案與 DOM；保留四個 `/*__...__*/` 組裝標記。
- `rules.js`：關卡、狀態與合法移動規則。
- `play.js`：操作事件、歷史、計分/過關 UI、儲存與提示，內含少量狀態文字。

執行 `node games/box-garden/build.cjs` 產生可直接玩的 `index.html`。打包時同一腳本作用域共享 `state`、`canvas`、`ctx`；`art.js` 的 `draw()` 由 render 呼叫，讀取 state 不改玩法。模型使用整數格子座標，不受像素繪圖造型限制；保留玩家與箱子位置、目的地的可辨識性。不要直接編輯生成的 index.html。

- `LEVELS` 保留三個練習關卡；執行時索引 3 可放入最新隨機關卡。`#` 牆、空格地板、`@` 玩家、`$` 箱子、`.` 目的地。各列寬度一致，一名玩家，箱子與目的地數量相同；`+` 是目的地上的玩家、`*` 是目的地上的箱子。
- `createState`、`advance`、`won` 為純邏輯，與繪圖分離；`history` 保存合法移動前的完整狀態，復原包含步數。
- 保留 `data-dir`、按鈕 id、Canvas 手勢和鍵盤事件。`?qa=1` 可使用 `gameQA.read/load/move/undo/generateLevel/randomLevel` 檢查狀態。
- 最佳步數存在 localStorage `box-garden-v1`；更改地圖後使用新 key，避免與舊成績混用。
- 角落提示只檢查非目的地牆角，不是完整死局求解器。

## 射擊遊戲

- `games/neon-range/index.html`：介面標題、說明、按鈕；保留事件用的 id 與 data 屬性。
- `style.css`：介面、觸控布局、media queries。
- `src/scene.js`：Three.js 初始化、材質、場景、角色與武器；可重建幾何與光線。
- `src/play.js`：控制、命中、計分、粒子、音效與觸控邏輯，含效果及狀態文案。
- `game.js`：由兩份來源依序合併產生，不直接編輯。這是以檔案分離可替換美術的輕量結構，仍共用變數，並非完整引擎插件系統。
- `vendor/`：完整本地 Three.js 依賴，不用網路 CDN。除非必要，不修改或讀取整份函式庫。
- `build-portable.cjs`：先合併 src/scene.js + src/play.js 成 game.js，再把 HTML、CSS、遊戲與依賴打包成 `NEON-RANGE-mobile.html`。原始碼入口需要 HTTP 服務，打包入口可直接離線開啟。
- 只改介面顏色不會改 3D 場景。機器人、武器和場景是程式組成幾何，不是可直接換檔的角色模型。
- 目前頭部獎勵使用命中點高度約 1.95 判斷；變更角色比例時需一併調整成對應部件的命中判定，否則加分與外觀不符。
- 保留 touchMode、joystick、look-zone、touch-fire 的多指控制與 pointercancel 清理；手機應能同時移動、瞄準、開火。
- 修改規則參數時檢查 reset、HUD、倒數比例等同步；它們目前不是集中配置。
- `?qa=1` 可用 `rangeQA` 與 `render_game_to_text()`，先查看原始碼確認介面；不要僅憑畫面斷言互動測試通過。

## 射擊造型與玩法連接

改場景時維持下列物件與資料，或同步更新 play.js 的呼叫者：

- `renderer`、`scene`、`camera`、`canvas`、`$`；resize 與鏡頭操作會使用它們。
- `robots` 列表內每個目標包含 `g`（Group）、`x/z`（基準位置）、`i`、`active`、`respawn`、`body`、`head`。可換成任何主題外觀，名稱只是程式欄位。
- 可命中的 Mesh 透過 `userData.robot` 指回目標。檢查 `shoot()`：只有該欄位被辨認的命中才會計分。
- `gun` 與 `flash` 由動作與槍口回饋使用；材質 `lime/cyan` 亦供粒子使用，可更換材質實作。
- 全新障礙物不是自動有碰撞。原版只限制玩家移動邊界，場景幾何不能當成已新增路徑或物理碰撞。

## 發布個人作品

專案不需後端、帳號或 AI API；正常遊玩不消耗 AI 額度。將個人專案作為靜態網站發布即可分享；部署前取得使用者對目的地的指示。老師既有網址只會顯示老師原版，不會自動顯示學生本地修改。

## 隨機關卡生成

`rules.js` 的 `generateLevel(seed)` 以種子產生 8×8、三箱地圖：從已完成狀態反向拉箱並保存反向步驟，回傳 `solution` 可驗證正向有解。嘗試次數有限，失敗時使用已知可解備用關。不要改成任意撒箱子而不驗證可解性。`play.js` 將隨機最佳步數以 `random-種子` 分開保存；重來沿用同一張地圖。改版若更換生成演算法，需變更成績 key 版本。

推箱子預設呼叫 `randomLevel()` 開始連續闖關；`challengeNumber` 記錄本次關次，`seenMaps` 檢查本次完整布局不重複。下一關與換關均產生新地圖，重來沿用當前地圖；原本三關是可選練習，不會在主闖關流程中循環。重新開啟頁面會開始新一輪，不保存跨次關次。
